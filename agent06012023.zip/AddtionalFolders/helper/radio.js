const getTrueFalse = (text)=>{
    if(text=='on'){
        return true
    }else{
        return false
    }
}


module.exports={
    getTrueFalse
}