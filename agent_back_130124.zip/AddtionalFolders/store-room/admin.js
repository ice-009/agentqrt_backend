// await AdminModel.Admin.create({
//     employeeId:1,
//     name:"superadmin",
//     email:"superadmin.agentqrt.@techqrt",
//     password:"superadmin",
//     username:"superadmin",
//    role:'superadmin',
// })