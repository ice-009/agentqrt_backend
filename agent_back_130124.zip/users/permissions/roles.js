const roles =  {
    ADMIN: 'admin',
    EMPLOYEE : 'user'
};