module.exports.outletController = require('../outlets/controllers/outlet')
module.exports.orderController = require('../special_feautres/order/controllers/order')
module.exports.employeeController = require('../users/controllers/employee')